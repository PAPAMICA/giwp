<?php
/**
 * Bootstrap interne — chargé par mainwp-giwp.php (ne pas activer ce fichier seul).
 *
 * @package MainWP_GIWeb
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'MAINWP_GIWEB_VERSION' ) ) {
	define( 'MAINWP_GIWEB_VERSION', '1.1.5' );
}
if ( ! defined( 'MAINWP_GIWEB_PLUGIN_FILE' ) ) {
	define( 'MAINWP_GIWEB_PLUGIN_FILE', __DIR__ . '/mainwp-giwp.php' );
}
if ( ! defined( 'MAINWP_GIWEB_PLUGIN_PATH' ) ) {
	define( 'MAINWP_GIWEB_PLUGIN_PATH', plugin_dir_path( MAINWP_GIWEB_PLUGIN_FILE ) );
}
if ( ! defined( 'MAINWP_GIWEB_PLUGIN_URL' ) ) {
	define( 'MAINWP_GIWEB_PLUGIN_URL', plugin_dir_url( MAINWP_GIWEB_PLUGIN_FILE ) );
}
if ( ! defined( 'MAINWP_GIWEB_GI_TOOLKIT_PATH' ) ) {
	define( 'MAINWP_GIWEB_GI_TOOLKIT_PATH', MAINWP_GIWEB_PLUGIN_PATH . '../wordpress_giwp/' );
}

require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-ui.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-sites.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-catalog.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-overrides.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-templates.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-history.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-bundle.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-modules-ui.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-api.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-deploy.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-notices.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb-sync-ajax.php';
require_once MAINWP_GIWEB_PLUGIN_PATH . 'includes/class-mainwp-giweb.php';

/**
 * Bootstrap extension MainWP.
 */
class MainWP_GIWeb_Extension_Activator {

	/** @var string */
	public $plugin_handle = 'mainwp-giwp';

	/** @var string */
	public $childFile;

	/** @var array<string, mixed>|false */
	public $childEnabled;

	/** @var string */
	public $childKey = '';

	/** @var bool */
	public $mainwpActivated = false;

	/**
	 * @return void
	 */
	public function __construct() {
		$this->childFile = MAINWP_GIWEB_PLUGIN_FILE;

		add_filter( 'mainwp_getextensions', array( $this, 'get_this_extension' ) );

		$this->mainwpActivated = (bool) apply_filters( 'mainwp_activated_check', false );

		if ( $this->mainwpActivated ) {
			$this->activate_extension();
		} else {
			add_action( 'mainwp_activated', array( $this, 'activate_extension' ) );
		}

		add_action( 'admin_notices', array( $this, 'admin_notice_mainwp_required' ) );

		add_filter( 'mainwp_extensions_page_top_header', array( $this, 'filter_extensions_page_title' ), 10, 2 );
		add_filter( 'admin_title', array( $this, 'filter_admin_document_title' ), 10, 2 );
		add_action( 'admin_enqueue_scripts', array( 'MainWP_GIWeb', 'enqueue_assets' ) );

		register_activation_hook( MAINWP_GIWEB_PLUGIN_FILE, array( 'MainWP_GIWeb_History', 'install_tables' ) );
	}

	/**
	 * Titre en-tête MainWP (évite « mainwp_giwp » / « _giwp » dérivé du dossier plugin).
	 *
	 * @param string $title Titre courant.
	 * @param string $page  Slug page admin.
	 * @return string
	 */
	public function filter_extensions_page_title( $title, $page ) {
		if ( MainWP_GIWeb_UI::is_extension_admin_page( $page ) ) {
			return MainWP_GIWeb_UI::page_title();
		}
		return $title;
	}

	/**
	 * Titre de l’onglet navigateur.
	 *
	 * @param string $admin_title Titre admin complet.
	 * @param string $title       Partie titre.
	 * @return string
	 */
	public function filter_admin_document_title( $admin_title, $title ) {
		if ( ! MainWP_GIWeb_UI::is_extension_admin_page() ) {
			return $admin_title;
		}
		$site = get_bloginfo( 'name', 'display' );
		return MainWP_GIWeb_UI::page_title() . ( $site ? ' ‹ ' . $site : '' );
	}

	/**
	 * @param array<int, array<string, mixed>> $extensions Extensions.
	 * @return array<int, array<string, mixed>>
	 */
	public function get_this_extension( $extensions ) {
		$extensions[] = array(
			'plugin'   => MAINWP_GIWEB_PLUGIN_FILE,
			'api'      => $this->plugin_handle,
			'name'     => MainWP_GIWeb_UI::page_title(),
			'mainwp'   => true,
			'callback' => array( $this, 'settings_page' ),
		);
		return $extensions;
	}

	/**
	 * @return void
	 */
	public function activate_extension() {
		$this->mainwpActivated = true;
		$this->childEnabled    = apply_filters( 'mainwp_extension_enabled_check', MAINWP_GIWEB_PLUGIN_FILE );
		if ( is_array( $this->childEnabled ) && ! empty( $this->childEnabled['key'] ) ) {
			$this->childKey = $this->childEnabled['key'];
		}
		add_filter( 'mainwp_getsubpages_extensions', array( $this, 'add_submenu' ), 10, 1 );
	}

	/**
	 * @param array<int, array<string, mixed>> $subpages Sous-pages.
	 * @return array<int, array<string, mixed>>
	 */
	public function add_submenu( $subpages ) {
		$subpages[] = array(
			'title'      => MainWP_GIWeb_UI::page_title(),
			'slug'       => 'Mainwp-Gi-Toolkit-Manager',
			'sitetab'    => false,
			'menu_hidden' => false,
			'callback'   => array( 'MainWP_GIWeb', 'render_page' ),
		);
		return $subpages;
	}

	/**
	 * @return void
	 */
	public function settings_page() {
		do_action( 'mainwp_pageheader_extensions', MAINWP_GIWEB_PLUGIN_FILE );
		if ( $this->childEnabled ) {
			MainWP_GIWeb::render_page();
		} else {
			echo '<div class="notice notice-error"><p>';
			esc_html_e( 'Extension non activée dans MainWP. Activez-la dans Extensions > Settings.', 'mainwp-giweb' );
			echo '</p></div>';
		}
		do_action( 'mainwp_pagefooter_extensions', MAINWP_GIWEB_PLUGIN_FILE );
	}

	/**
	 * @return void
	 */
	public function admin_notice_mainwp_required() {
		if ( $this->mainwpActivated ) {
			return;
		}
		global $current_screen;
		if ( isset( $current_screen->parent_base ) && 'plugins' === $current_screen->parent_base ) {
			echo '<div class="notice notice-warning"><p>';
			esc_html_e( 'MainWP GI-Web Extension nécessite MainWP Dashboard.', 'mainwp-giweb' );
			echo '</p></div>';
		}
	}

	/**
	 * @return string
	 */
	public function getChildKey() {
		return $this->childKey;
	}

	/**
	 * @return string
	 */
	public function getChildFile() {
		return $this->childFile;
	}
}

global $mainwp_giweb_activator;
$mainwp_giweb_activator = new MainWP_GIWeb_Extension_Activator();

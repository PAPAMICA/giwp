<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="mainwp-giweb-sync-modal" class="mainwp-giweb-modal" aria-hidden="true" role="dialog" aria-labelledby="mainwp-giweb-sync-modal-title">
	<div class="mainwp-giweb-modal__backdrop" tabindex="-1"></div>
	<div class="mainwp-giweb-modal__dialog">
		<header class="mainwp-giweb-modal__header">
			<h2 id="mainwp-giweb-sync-modal-title"><?php esc_html_e( 'Synchronisation des statuts', 'mainwp-giweb' ); ?></h2>
		</header>
		<div class="mainwp-giweb-modal__body">
			<div class="mainwp-giweb-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
				<div class="mainwp-giweb-progress__bar" style="width: 0%;"></div>
			</div>
			<p class="mainwp-giweb-progress__label">0 / 0</p>
			<div class="mainwp-giweb-sync-log" aria-live="polite" aria-relevant="additions"></div>
		</div>
		<footer class="mainwp-giweb-modal__footer">
			<button type="button" class="button button-primary mainwp-giweb-modal__close" disabled>
				<?php esc_html_e( 'Fermer', 'mainwp-giweb' ); ?>
			</button>
		</footer>
	</div>
</div>
